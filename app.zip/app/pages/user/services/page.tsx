'use client'

import * as React from "react"

import {
    Card,
    CardContent,
    // CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from "@/components/ui/card"

import MainLayout from "@/app/components/mainLayout"

export default function Services() {
    return (
        <MainLayout>
            <div className="flex justify-center items-center min-h-screen space-x-12">
                {/* Card 1 */}
                <a href="/pages/user/football">
                    <div className="w-96 hover:scale-105 hover:border-2 hover:border-red-700">
                        <Card
                            className="h-[35rem] relative overflow-hidden"
                            style={{
                                backgroundImage: `linear-gradient(to bottom, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6 )), url('/user/img/service-football.jpg')`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                            }}
                        >
                            <CardHeader>
                                <CardTitle className="text-white text-center mt-20">สนามฟุตบอล</CardTitle>
                                {/* <CardDescription className="text-gray-200">รายละเอียดเกี่ยวกับสนามฟุตบอล</CardDescription> */}
                            </CardHeader>
                            <CardContent>
                                {/* <p className="text-white">เนื้อหาสนามฟุตบอล</p> */}
                            </CardContent>
                            <CardFooter>
                                {/* <p className="text-gray-300">Footer ของสนามฟุตบอล</p> */}
                            </CardFooter>
                        </Card>
                    </div>
                </a>
                <a href="/pages/user/exercise">
                    {/* Card 2 */}
                    <div className="w-96 hover:scale-105 hover:border-2 hover:border-red-700">
                        <Card
                            className="h-[35rem] relative overflow-hidden"
                            style={{
                                backgroundImage: `linear-gradient(to bottom, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6 )), url('/user/img/service-exercise2.png')`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                            }}
                        >
                            <CardHeader>
                                <CardTitle className="text-white text-center mt-20">ออกกำลังกาย</CardTitle>
                                {/* <CardDescription className="text-gray-200">รายละเอียดเกี่ยวกับการออกกำลังกาย</CardDescription> */}
                            </CardHeader>
                            <CardContent>
                                {/* <p className="text-white">เนื้อหาเกี่ยวกับการออกกำลังกาย</p> */}
                            </CardContent>
                            <CardFooter>
                                {/* <p className="text-gray-300">Footer ของการออกกำลังกาย</p> */}
                            </CardFooter>
                        </Card>
                    </div>
                </a>
            </div>
        </MainLayout>
    )
}
