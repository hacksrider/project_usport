"use client";
import axios from "axios";
import MainLayout from "@/app/components/mainLayout";
import { useState } from "react";
import { useRouter } from "next/navigation";

const RegisterForm: React.FC = () => {
    const [formData, setFormData] = useState({
        user_name: "",
        user_lastname: "",
        // emp_sex: "",
        user_date_of_birth: "",
        user_tel: "",
        ID_card_photo: File,
        accom_rent_contrac_photo: File,
        user_username: "",
        user_password: "",
        // status_of_VIP: "",
        user_email: "",
        password: "",
        consent: false,
    });
    const router = useRouter();
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === "checkbox" ? checked : value,
        });
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, files } = e.target;
        if (files && files.length > 0) {
            setFormData({
                ...formData,
                [name]: files[0],
            });
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (formData.user_password !== formData.password) {
            alert("user_passwords do not match!");
            return;
        }
        if (!formData.consent) {
            alert("You need to consent to data disclosure!");
            return;
        }
        console.log("Form submitted:", formData);

        try {
            const apiFormData = new FormData();

            Object.entries(formData).forEach(([key, value]) => {
                if (key === "ID_card_photo" || key === "accom_rent_contrac_photo") {
                    if (value instanceof File) {
                        apiFormData.append(key, value);
                    }
                } else {
                    apiFormData.append(key, String(value));
                }
            });
            const response = await axios.post("/api/user", apiFormData);
            if (response.status === 200) {
                alert("Registration successful!");
                router.push("/pages/user/login");
            }
        } catch (error) {
            alert(error);
            return console.error(error);
            
        }
    };

    return (
        <MainLayout>
            <div className="mt-8 mb-8 max-w-md mx-auto bg-white shadow-md rounded-lg p-6">
                <h2 className="text-2xl font-bold mb-4">Register</h2>
                <p className="mb-6 text-gray-600">Enter your information to create an account</p>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <label htmlFor="user_name" className="block text-sm font-medium text-gray-700">
                            First Name
                        </label>
                        <input
                            type="text"
                            id="user_name"
                            name="user_name"
                            placeholder="Enter your First name"
                            value={formData.user_name}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="user_lastname" className="block text-sm font-medium text-gray-700">
                            Last Name
                        </label>
                        <input
                            type="text"
                            id="user_lastname"
                            name="user_lastname"
                            placeholder="Enter your Last name"
                            value={formData.user_lastname}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="user_date_of_birth" className="block text-sm font-medium text-gray-700">
                            Birth of Date
                        </label>
                        <input
                            type="date"
                            id="user_date_of_birth"
                            name="user_date_of_birth"
                            placeholder="Enter your Birth Date"
                            value={formData.user_date_of_birth}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div>
                    {/* <div className="mb-4">
                        <label htmlFor="emp_sex" className="block text-sm font-medium text-gray-700">
                            Gender
                        </label>
                        <input
                            type="text"
                            id="emp_sex"
                            name="emp_sex"
                            value={formData.emp_sex}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div> */}
                    <div className="mb-4">
                        <label htmlFor="user_tel" className="block text-sm font-medium text-gray-700">
                            Phone Number
                        </label>
                        <input
                            type="tel"
                            id="user_tel"
                            name="user_tel"
                            placeholder="Enter your Phone Number"
                            value={formData.user_tel}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div>
                    {/* <div className="mb-4">
                        <label htmlFor="status_of_VIP" className="block text-sm font-medium text-gray-700">
                            status_of_VIP
                        </label>
                        <input
                            type="text"
                            id="status_of_VIP"
                            name="status_of_VIP"
                            value={formData.status_of_VIP}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div> */}
                    <div className="mb-4">
                        <label htmlFor="ID_card_photo" className="block text-sm font-medium text-gray-700">
                            ID Card Image
                        </label>
                        <div className="relative">
                            <input
                                type="file"
                                id="ID_card_photo"
                                name="ID_card_photo"
                                placeholder="Enter your ID Card Image"
                                onChange={handleFileChange}
                                className="p-2 h-10 block w-full text-sm text-gray-700 border border-black rounded-md flex items-center"
                                required
                                style={{ display: "flex", alignItems: "center" }}
                            />
                        </div>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="accom_rent_contrac_photo" className="block text-sm font-medium text-gray-700">
                            Rental Proof Image
                        </label>
                        <div className="relative">
                            <input
                                type="file"
                                id="accom_rent_contrac_photo"
                                name="accom_rent_contrac_photo"
                                placeholder="Enter your Rental Proof Image"
                                onChange={handleFileChange}
                                className="p-2 h-10 block w-full text-sm text-gray-700 border border-black rounded-md flex items-center"
                                style={{ display: "flex", alignItems: "center" }}
                            />
                        </div>
                    </div>
                    <div className="mb-4">
                        <label htmlFor="user_username" className="block text-sm font-medium text-gray-700">
                            Username
                        </label>
                        <input
                            type="text"
                            id="user_username"
                            name="user_username"
                            placeholder="Enter your Username"
                            value={formData.user_username}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="user_email" className="block text-sm font-medium text-gray-700">
                            Email
                        </label>
                        <input
                            type="user_email"
                            id="user_email"
                            name="user_email"
                            placeholder="Enter your Email"
                            value={formData.user_email}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="user_password" className="block text-sm font-medium text-gray-700">
                            Password
                        </label>
                        <input
                            type="password"
                            id="user_password"
                            name="user_password"
                            placeholder="Enter your Password"
                            value={formData.user_password}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                            Confirm password
                        </label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Enter your Confirm Password"
                            value={formData.password}
                            onChange={handleChange}
                            className="mt-1 pl-2 h-10 block w-full border border-black rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label className="flex items-center">
                            <input
                                type="checkbox"
                                name="consent"
                                checked={formData.consent}
                                onChange={handleChange}
                                className="mr-2"
                            />
                            I consent to the disclosure of my information
                        </label>
                    </div>
                    <button
                        type="submit"
                        className="w-full bg-indigo-600 text-white py-2 px-4 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                        Register
                    </button>
                </form>
                <p className="mt-6 text-center text-gray-600">
                    Already have an account? <a href="/pages/user/login" className="text-indigo-600 hover:underline">Login</a>
                </p>
            </div>
        </MainLayout>
    );
};

export default RegisterForm;