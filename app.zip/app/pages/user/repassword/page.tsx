'use client';

import React from 'react';
import MainLayout from '@/app/components/mainLayout';

export default function Repassword() {
  return (
    <MainLayout>
      <div className="flex justify-center items-center min-h-screen bg-gray-100">
        <div className="bg-white p-8 rounded shadow-md w-full max-w-sm">
          <h2 className="text-2xl font-bold mb-6 text-center">Set a New Password</h2>
          <p className="mb-4 text-center">Enter your new password and confirm it to set a new password.</p>
          <form>
            <div className="mb-4">
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
              <input
                type="password"
                id="password"
                className="mt-1 w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring focus:border-blue-300"
                placeholder="********"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">Confirm Password</label>
              <input
                type="password"
                id="confirmPassword"
                className="mt-1 w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring focus:border-blue-300"
                placeholder="********"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-3 rounded hover:bg-blue-700 transition duration-300"
            >
              Set New Password
            </button>
          </form>
          <div className="mt-6 text-center">
            <a href="/pages/user/login" className="text-blue-600 hover:underline">&larr; Back to Login</a>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
