'use client'

import React, { useState } from 'react';
import MainLayout from '@/app/components/mainLayout';
import { format, addDays } from 'date-fns';
import 'tailwindcss/tailwind.css';
import {
    Card,
    // CardContent,
    // CardDescription,
    // CardFooter,
    CardHeader,
    CardTitle,
} from "@/components/ui/card"
interface Booking {
    date: string;
    hours: number[];
    type: 'other' | 'successful';
}

export default function Booking() {
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [selectedHours, setSelectedHours] = useState<number[]>([]);

    const mockBookings: Booking[] = [
        {
            date: format(new Date(), 'dd-MM-yyyy'),
            hours: [10, 11],
            type: 'other'
        },
        {
            date: format(addDays(new Date(), 1), 'dd-MM-yyyy'),
            hours: [15, 16],
            type: 'successful'
        }
    ];

    const datesToDisplay = Array.from({ length: 7 }, (_, i) => addDays(new Date(), i));

    const toggleHour = (hour: number, date: Date) => {
        const dateStr = format(date, 'dd-MM-yyyy');
        if (format(selectedDate, 'dd-MM-yyyy') === dateStr) {
            setSelectedHours(prevHours =>
                prevHours.includes(hour) ? prevHours.filter(h => h !== hour) : [...prevHours, hour]
            );
        } else {
            setSelectedDate(date);
            setSelectedHours([hour]);
        }
    };

    const calculatePrice = () => {
        if (selectedHours.length === 0) {
            return 0;
        }
        const isEveningHour = (hour: number) => hour >= 17;

        if (selectedHours.length === 1) {
            return isEveningHour(selectedHours[0]) ? 1000 : 800;
        }

        selectedHours.sort((a, b) => a - b);
        let totalPrice = 0;
        let i = 0;

        while (i < selectedHours.length) {
            if (i + 1 < selectedHours.length && selectedHours[i + 1] === selectedHours[i] + 1) {
                // Pair of consecutive hours
                totalPrice += isEveningHour(selectedHours[i]) ? 1500 : 1200;
                i += 2;
            } else {
                // Single hour
                totalPrice += isEveningHour(selectedHours[i]) ? 1000 : 800;
                i += 1;
            }
        }

        return totalPrice;
    };

    return (
        <MainLayout>
            <div className="p-4 bg-gray-400">
                {/* Search bar */}
                <div className="flex justify-between items-center mr-20">
                    <h1 className="text-2xl font-bold mr-4 ml-48">สนามฟุตบอล 1 VIP</h1>
                    <input
                        type="text"
                        value={format(selectedDate, 'dd-MM-yyyy')} // แสดงวันที่ในรูปแบบ dd-MM-yyyy
                        placeholder="ค้นหาวันที่"
                        onFocus={(e) => (e.target.type = 'date')} // เปลี่ยน type เป็น date เมื่อคลิก
                        onBlur={(e) => (e.target.type = 'text')} // เปลี่ยนกลับเป็น text เมื่อคลิกออก
                        onChange={(e) => setSelectedDate(new Date(e.target.value))}
                        className="border p-2 mb-4 w-60 text-center"
                    />
                </div>

                {/* Booking Calendar */}
                <div className="grid grid-cols-8 gap-2 mr-20">
                    <div></div>
                    {datesToDisplay.map((date) => (
                        <div key={date.toString()} className="font-bold text-center">
                            {format(date, 'MMM dd')}
                        </div>
                    ))}

                    {[...Array(16)].map((_, hourIndex) => (
                        <React.Fragment key={hourIndex}>
                            <div className="text-right pr-2 font-bold text-center mt-2">
                                {`${9 + hourIndex}:00`}
                            </div>
                            {datesToDisplay.map((date) => {
                                const dateStr = format(date, 'dd-MM-yyyy');
                                const isBooked = mockBookings.find(
                                    (b) => b.date === dateStr && b.hours.includes(9 + hourIndex)
                                );
                                const isSelected = selectedHours.includes(9 + hourIndex) && format(selectedDate, 'dd-MM-yyyy') === dateStr;
                                return (
                                    <div
                                        key={dateStr + hourIndex}
                                        className={`h-10 w-full cursor-pointer flex items-center justify-center ${isBooked
                                            ? isBooked.type === 'successful'
                                                ? 'bg-red-500'
                                                : 'bg-yellow-500'
                                            : isSelected
                                                ? 'bg-green-500'
                                                : 'bg-gray-200'
                                            }`}
                                        onClick={() => {
                                            if (!isBooked) toggleHour(9 + hourIndex, date);
                                        }}
                                    >
                                        {isBooked
                                            ? isBooked.type === 'successful'
                                                ? 'ไม่ว่าง'
                                                : 'ติดจอง'
                                            : isSelected
                                                ? 'เลือก'
                                                : 'ว่าง'
                                        }
                                    </div>
                                );
                            })}
                        </React.Fragment>
                    ))}
                </div>

                {/* Price Calculation */}
                <div className="flex justify-end mt-4 mr-20 font-bold text-xl">
                    <Card><CardHeader><CardTitle>Total Price: {calculatePrice()} Baht</CardTitle></CardHeader></Card>
                </div>

                {/* Next Page Button */}
                <div className='flex justify-end'>
                    <button className="mt-4 mr-20 px-4 py-2 bg-blue-500 text-white rounded">
                        Proceed to Next Page
                    </button>
                </div>
            </div>
        </MainLayout>
    );
}
