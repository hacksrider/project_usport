'use client'
import React from 'react'
import MainLayout from '@/app/components/mainLayout'

export default function Edit_Profile() {
  return (
    <MainLayout>
      <h1>Edit_Profile</h1>
    </MainLayout>
  )
}