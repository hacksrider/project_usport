'use client'

// import { View, Text } from 'react-native'
import React from 'react'

export default function page() {
    return (
        <>
            <h1>Exercise</h1>
        </>
    )
}