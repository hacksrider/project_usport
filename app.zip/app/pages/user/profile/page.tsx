/* eslint-disable @next/next/no-img-element */
'use client';
import MainLayout from '@/app/components/mainLayout';
import { UserInterface } from '@/app/interface/user';
import { useSession } from 'next-auth/react';

function formatDateThai(dateString: string): string {
  const date = new Date(dateString);
  const months = [
    'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
    'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
  ];
  const day = date.getDate();
  const month = months[date.getMonth()];
  const year = date.getFullYear() + 543; // แปลงเป็นปี พ.ศ.
  return `${day} ${month} ${year}`;
}

function calculateAge(dateString: string): number {
  const birthDate = new Date(dateString);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}

export default function Profile() {
  const { data } = useSession();
  const userData = data as UserInterface;

  const dateOfBirth = userData?.user?.user_date_of_birth || ""; // ตรวจสอบว่าข้อมูลมีอยู่หรือไม่
const formattedDate = dateOfBirth ? formatDateThai(dateOfBirth) : "N/A";
const age = dateOfBirth ? calculateAge(dateOfBirth) : "N/A";


  return (
    <MainLayout>
      <div className="w-full h-full from-blue-600 via-purple-600 to-indigo-600 pt-12">
        <div className="max-w-5xl mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3">
            <div className="bg-gradient-to-b from-indigo-600 to-purple-600 p-6 text-center">
              <div className="w-36 h-36 mx-auto rounded-full bg-gray-300 overflow-hidden shadow-xl">
                <img
                  src="/path-to-placeholder-image.jpg" // Replace with dynamic profile image source
                  alt="Profile Picture"
                  className="w-full h-full object-cover"
                />
              </div>
              <h2 className="mt-4 text-2xl font-bold text-white">{userData.user.user_username || "N/A"}</h2>
              <p className="text-white text-sm">{userData.user.user_name || "N/A"} {userData.user.user_lastname || "N/A"}</p>
              <button className="mt-6 px-4 py-2 bg-white text-purple-600 font-semibold rounded-full shadow-md hover:bg-gray-100">
                Change Picture
              </button>

              <div className="mt-6 flex flex-col">
                  <label className="text-lg text-gray-900 text-bold">VIP Status</label>
                  <div className="text-lg font-semibold text-green-500">Active</div>
                </div>
            </div>

            <div className="col-span-2 p-6">
              <h3 className="text-xl font-semibold text-gray-700 mb-6">Profile Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col">
                  <label className="text-sm text-gray-500">First Name</label>
                  <div className="text-lg font-semibold text-gray-800">{userData?.user?.user_name || "N/A"}</div>
                </div>
                <div className="flex flex-col">
                  <label className="text-sm text-gray-500">Last Name</label>
                  <div className="text-lg font-semibold text-gray-800">{userData.user.user_lastname || "N/A"}</div>
                </div>
                <div className="flex flex-col">
                  <label className="text-sm text-gray-500">Email</label>
                  <div className="text-lg font-semibold text-gray-800">{userData.user.user_email || "N/A"}</div>
                </div>
                <div className="flex flex-col">
                  <label className="text-sm text-gray-500">Username</label>
                  <div className="text-lg font-semibold text-gray-800">{userData.user.user_username || "N/A"}</div>
                </div>
                <div className="flex flex-col">
                  <label className="text-sm text-gray-500">Date of Birth</label>
                  <div className="text-lg font-semibold text-gray-800">{formattedDate}</div>
                </div>
                <div className="flex flex-col">
                  <label className="text-sm text-gray-500">Age</label>
                  <div className="text-lg font-semibold text-gray-800">{age}</div>
                </div>
                <div className="flex flex-col">
                  <label className="text-sm text-gray-500">Phone</label>
                  <div className="text-lg font-semibold text-gray-800">{userData.user.user_tel || "N/A"}</div>
                </div>
                
                <div className="flex flex-col">
                  <label className="text-sm text-gray-500">เป็นสมาชิกเมื่อ</label>
                  <div className="text-lg font-semibold text-gray-800">01/01/2010</div>
                </div>
              </div>

              <div className="mt-8 text-right">
                <button className="px-6 py-3 bg-purple-600 text-white font-bold rounded-lg shadow-md hover:bg-purple-700 transition">
                  Edit Profile
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
