'use server'

import React from 'react'
// import Image from 'next/image'
import MainLayoutAdmin from '@/app/components/mainLayoutAdmin'



export default async function FootballField_2() {
    return (
        <MainLayoutAdmin>
            
            <h1>Football Field2</h1>

        </MainLayoutAdmin>
    )
}