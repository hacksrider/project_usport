

import React from "react";
import MainLayoutAdmin from "@/app/components/mainLayoutAdmin";

export default async function Dashboard() {
    return (
        <MainLayoutAdmin>
            <div className="p-6">
                {/* Header Section */}
                <div className="flex flex-col md:flex-row items-center justify-between mb-6">
                    <div>
                        <h1 className="text-2xl font-bold">Activated Users</h1>
                        <p className="text-gray-600">REPORT FOR LAST 7-DAYS AGO</p>
                    </div>
                    <div className="mt-4 md:mt-0">
                        <button className="bg-pink-500 text-white px-4 py-2 rounded shadow">View Details</button>
                    </div>
                </div>

                {/* Metrics Section */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                    <div className="bg-blue-500 text-white p-4 rounded shadow">
                        <p className="text-lg font-bold">53</p>
                        <p>Sales</p>
                    </div>
                    <div className="bg-purple-500 text-white p-4 rounded shadow">
                        <p className="text-lg font-bold">32</p>
                        <p>Projects</p>
                    </div>
                    <div className="bg-yellow-500 text-white p-4 rounded shadow">
                        <p className="text-lg font-bold">68</p>
                        <p>Messages</p>
                    </div>
                    <div className="bg-gray-800 text-white p-4 rounded shadow">
                        <p className="text-lg font-bold">12</p>
                        <p>Reports</p>
                    </div>
                </div>

                {/* User List Section */}
                <div className="bg-white shadow rounded p-4">
                    <table className="w-full table-auto">
                        <thead>
                            <tr className="text-left bg-gray-100">
                                <th className="px-4 py-2">#</th>
                                <th className="px-4 py-2">User</th>
                                <th className="px-4 py-2">Full Name</th>
                                <th className="px-4 py-2">Email</th>
                                <th className="px-4 py-2">Subscription</th>
                                <th className="px-4 py-2">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {[1, 2, 3, 4, 5, 6].map((id) => (
                                <tr key={id} className="border-b">
                                    <td className="px-4 py-2">{id}</td>
                                    <td className="px-4 py-2">
                                        <div className="flex items-center">
                                            <div className="w-8 h-8 bg-blue-200 rounded-full mr-2"></div>
                                            User {id}
                                        </div>
                                    </td>
                                    <td className="px-4 py-2">John Doe</td>
                                    <td className="px-4 py-2">john.doe@example.com</td>
                                    <td className="px-4 py-2">
                                        <span className="bg-blue-500 text-white px-2 py-1 rounded">Trial</span>
                                    </td>
                                    <td className="px-4 py-2">
                                        <button className="text-blue-500 hover:underline">Edit</button>
                                        <button className="text-red-500 hover:underline ml-2">Delete</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </MainLayoutAdmin>
    );
}