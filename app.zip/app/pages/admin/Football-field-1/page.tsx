'use server'

import React from 'react'
// import Image from 'next/image'
import MainLayoutAdmin from '@/app/components/mainLayoutAdmin'



export default async function FootballField_1() {
    return (
        <MainLayoutAdmin>
            
            <h1>Football Field</h1>

        </MainLayoutAdmin>
    )
}