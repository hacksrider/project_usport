import Home from "./pages/user/home/page";
// import Dashboard from "./pages/admin/dashboard/page"; 
export default function Index() {
  return (
    // < Dashboard />
    < Home />
  );
}
