export interface UserInterface {
    user: User
    expires: string
  }
  
  export interface User {
    id: string
    user_name: string
    user_lastname: string
    user_date_of_birth: string
    user_email: string
    user_tel: string
    user_username: string
    ID_card_photo: string
    accom_rent_contrac_photo: string
    status_of_VIP: boolean
  }
  