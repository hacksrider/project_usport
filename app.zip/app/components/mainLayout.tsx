/* eslint-disable @next/next/no-img-element */
import React, { useState, useRef, useEffect } from 'react';
import { FaFacebook, FaTwitter, FaInstagram } from 'react-icons/fa';
import { FaChevronDown } from 'react-icons/fa';
import Image from 'next/image';
import { useSession, signOut } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { UserInterface } from '../interface/user';

interface mainLayoutProp {
  children: React.ReactNode;
}

export default function MainLayout({ children }: mainLayoutProp) {
  const { data, status } = useSession();
  const userData = data as UserInterface;
  const router = useRouter();

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const toggleDropdown = () => {
    setDropdownOpen((prev) => !prev);
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
      setDropdownOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <div className="bg-red-600 p-7 sticky top-0 z-50 px-20">
        <nav className="container mx-auto flex justify-between items-center">
          <Image src="/user/img/logo.png" alt="Login" width={96} height={96} className="ml-10" unoptimized />
          <div className="flex justify-between items-center">
            <ul className="pr-7 flex space-x-6 items-center">
              <li>
                <a onClick={() => router.push('/pages/user/home')} className="text-white hover:text-gray-200 hover:underline hover:underline-offset-8 text-2xl">
                  หน้าแรก
                </a>
              </li>
              <li>
                <a onClick={() => router.push('/pages/user/services')} className="text-white hover:text-gray-200 hover:underline hover:underline-offset-8 text-2xl">
                  เกี่ยวกับเรา
                </a>
              </li>
              <li>
                <a onClick={() => router.push('/pages/user/services')} className="text-white hover:text-gray-200 hover:underline hover:underline-offset-8 text-2xl">
                  บริการ
                </a>
              </li>
              <li>
                <a href="#" className="text-white hover:text-gray-200 hover:underline hover:underline-offset-8 text-2xl">
                  ติดต่อเรา
                </a>
              </li>
            </ul>
            <ul className="flex space-x-2 items-center">
              {status === 'unauthenticated' && (
                <>
                  <button
                    className="border-solid border-slate-950 bg-red-100 hover:bg-red-700 text-black font-bold py-2 px-4 mr-0"
                    onClick={() => router.push('/pages/user/login')}
                  >
                    เข้าสู่ระบบ
                  </button>
                  <button
                    className="border-solid border-slate-950 bg-red-100 hover:bg-red-700 text-black font-bold py-2 px-4 ml-0"
                    onClick={() => router.push('/pages/user/register')}
                  >
                    สมัครสมาชิก
                  </button>
                </>
              )}
              {status === 'authenticated' && (
                <div className="relative" ref={dropdownRef}>
                  <button
                    className="flex items-center text-white font-bold hover:text-gray-300 focus:outline-none"
                    onClick={toggleDropdown}
                  >
                    <div className='mr-2 w-10 h-10 rounded-full overflow-hidden'><img src="/user/img/hacks.png" alt="user" /></div>
                    {userData.user.user_username}
                    <FaChevronDown className="ml-2" />
                  </button>
                  {dropdownOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded shadow-lg">
                      <ul className="py-1">
                        <li>
                          <button
                            onClick={() => router.push('/pages/user/profile')}
                            className="w-full text-left block px-4 py-2 text-gray-700 hover:bg-gray-100"
                          >
                            ดูโปรไฟล์
                          </button>
                        </li>
                        <li>
                          <button
                            className="w-full text-left block px-4 py-2 text-gray-700 hover:bg-gray-100"
                            onClick={() => signOut({ callbackUrl: '/pages/user/login' })}
                          >
                            ล็อกเอาท์
                          </button>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </ul>
          </div>
        </nav>
      </div>
      <div className="flex-grow bg-gray-300">{children}</div>
      <div className="bg-black p-4">
        {/* Footer */}
        <footer className="container mx-auto text-center text-white">
          <p>&copy; 2024 U-Sport. All rights reserved.</p>
          <div className="flex justify-center space-x-4 mt-4">
            <a href="#" className="text-white hover:text-gray-400">
              <FaFacebook size={24} />
            </a>
            <a href="#" className="text-white hover:text-gray-400">
              <FaTwitter size={24} />
            </a>
            <a href="#" className="text-white hover:text-gray-400">
              <FaInstagram size={24} />
            </a>
          </div>
        </footer>
      </div>
    </div>
  );
}
