'use client';
import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';

interface MainLayoutAdminProp {
    children: React.ReactNode;
}

export default function MainLayoutAdmin({ children }: MainLayoutAdminProp) {
    const [activeMenu, setActiveMenu] = useState(''); // Default active item
    const [menuVisible, setMenuVisible] = useState(false); // Manage menu visibility
    const [profileMenuVisible, setProfileMenuVisible] = useState(false); // Manage profile menu visibility
    const [pagesMenuVisible, setPagesMenuVisible] = useState(false); // Manage profile menu visibility

    const router = useRouter();
    const pathName = usePathname();
    // Update the active item on page load (e.g., dashboard)
    useEffect(() => {

        const pName = pathName.split('/').filter(Boolean).pop()
        setActiveMenu(pName!);
        setMenuVisible(true);
    }, [pathName, router]);

    // const handleMenuClick = (menu: string) => {
    //     setActiveMenu(menu);
    // };

    const toggleMenuVisibility = () => {
        setMenuVisible(!menuVisible);
    };

    const toggleProfileMenuVisibility = () => {
        setProfileMenuVisible(!profileMenuVisible);
    };
    const togglePagesMenuVisibility = () => {
        setPagesMenuVisible(!pagesMenuVisible);
    };

    return (
        <div className="min-h-screen bg-gray-300 flex flex-col w-full">
            <div className="w-full h-16 text-white pt-3 pl-4 bg-red-800 flex items-center fixed top-0 z-50">
                <Image src="/user/img/logo.png" alt="Login" width={96} height={96} className="ml-12 mt-0 mb-2" unoptimized />
            </div>
            <div className="flex mt-7">
                {/* Sidebar */}
                <aside className="fixed w-64 h-full bg-gray-700 text-white p-6 flex flex-col justify-between overflow-y-auto">
                    <div className="mt-10">
                        <div className="flex flex-col items-center mb-0 mt-0">
                            <div className="w-[120px] h-[auto] rounded-full bg-gray-300 mb-4 overflow-hidden">
                                <Image
                                    src="/user/img/hacks.png"
                                    alt="Profile Image"
                                    width={100}
                                    height={100}
                                    className="object-cover w-full h-full"
                                />
                            </div>
                            <div
                                className="text-center cursor-pointer flex items-center justify-center"
                                onClick={toggleProfileMenuVisibility}
                            >
                                <div className="text-center cursor-pointer flex flex-col items-center justify-center"
                                    onClick={toggleProfileMenuVisibility}>
                                    <div className="flex items-center">
                                        <h2 className="text-lg font-semibold">Hacks Rider</h2>
                                        <span className={`ml-2 transition-transform ${profileMenuVisible ? 'rotate-180' : ''}`}>&#x25BC;</span>
                                    </div>
                                    <p className="text-sm text-gray-400">ผู้จัดการ</p>
                                </div>

                            </div>
                            {profileMenuVisible && (
                                <ul className='border-b border-gray-600 w-full'>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'profile' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">📁</span>Profile
                                        </a>
                                    </li>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'setting' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">📁</span>Setting
                                        </a>
                                    </li>
                                </ul>
                            )}
                        </div>
                        <nav>
                            <ul className='border-b border-gray-600'>
                                <li
                                    className="cursor-pointer flex items-center"
                                    onClick={() => {
                                        setActiveMenu('dashboard'); // ตั้ง activeMenu ตามเมนูที่คลิก
                                        router.push('/pages/admin/dashboard');
                                    }}
                                >
                                    <a
                                        className={`flex items-center text-white w-full px-2 py-2 rounded ${activeMenu === 'dashboard' ? 'bg-gray-500' : ''
                                            }`}
                                    >
                                        <span className="mr-3">🏠</span>Dashboard
                                    </a>
                                </li>

                                <li
                                    className="cursor-pointer flex items-center"
                                    onClick={() => {
                                        setActiveMenu('member');
                                        router.push('/pages/admin/member');
                                    }}
                                >
                                    <a
                                        className={`flex items-center text-white w-full px-2 py-2 rounded ${activeMenu === 'member' ? 'bg-gray-500' : ''
                                            }`}
                                    >
                                        <span className="mr-3">📁</span>Member
                                    </a>
                                </li>

                            </ul>
                            <div>
                                {/* เมนูหลัก Main */}
                                <div
                                    className="text-white font-bold text-lg flex items-center cursor-pointer px-4 py-2 rounded relative"
                                    onClick={() => { toggleMenuVisibility(); }} // เปิด/ปิด Main Menu
                                >
                                    <h1 className="w-full">Main</h1>
                                    <span className={`ml-auto transition-transform ${menuVisible ? 'rotate-180' : ''}`}>&#x25BC;</span>
                                </div>

                                {/* รายการใน Main Menu */}
                                {menuVisible && ( // แสดงรายการเฉพาะเมื่อ menuVisible เป็น true
                                    <ul className="border-b border-gray-600" >
                                        <li
                                            className={`cursor-pointer flex items-center ${activeMenu === 'Football-field-1' ? 'bg-gray-500' : ''
                                                }`}
                                            onClick={() => {
                                                setActiveMenu('Football field 1'); // ตั้ง activeMenu
                                                router.push('/pages/admin/Football-field-1'); // เปลี่ยนเส้นทาง
                                            }}
                                        >
                                            <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                                <span className="mr-3">📁</span>Football field 1
                                            </a>
                                        </li>
                                        <li
                                            className={`cursor-pointer flex items-center ${activeMenu === 'Football-field-2' ? 'bg-gray-500' : ''
                                                }`}
                                            onClick={() => {
                                                setActiveMenu('Football field 2'); // ตั้ง activeMenu
                                                router.push('/pages/admin/Football-field-2'); // เปลี่ยนเส้นทาง
                                            }}
                                        >
                                            <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                                <span className="mr-3">🔧</span>Football field 2
                                                <span className="ml-auto bg-gray-300 text-red-900 rounded-full px-2">24</span>
                                            </a>
                                        </li>
                                    </ul>
                                )}
                            </div>

                            <div
                                className="text-white font-bold text-lg flex items-center cursor-pointer px-4 py-2 rounded relative"
                                onClick={togglePagesMenuVisibility}
                            >
                                <h1 className="w-full">Pages</h1>
                                <span className={`ml-auto transition-transform ${pagesMenuVisible ? 'rotate-180' : ''}`}>&#x25BC;</span>
                            </div>
                            {pagesMenuVisible && (
                                <ul className='border-b border-gray-600'>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'home' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">📁</span>home
                                        </a>
                                    </li>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'about' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">🔧</span>about <span className="ml-auto bg-gray-300 text-red-900 rounded-full px-2">24</span>
                                        </a>
                                    </li>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'service' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">📝</span>service
                                        </a>
                                    </li>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'contact' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">📝</span>contact
                                        </a>
                                    </li>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'contact' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">📝</span>contact
                                        </a>
                                    </li>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'contact' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">📝</span>contact
                                        </a>
                                    </li>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'contact' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">📝</span>contact
                                        </a>
                                    </li>
                                    <li
                                        className={`cursor-pointer flex items-center ${activeMenu === 'contact' ? 'bg-gray-500' : ''}`}

                                    >
                                        <a className="flex items-center text-white w-full px-2 py-2 rounded">
                                            <span className="mr-3">📝</span>contact
                                        </a>
                                    </li>
                                </ul>
                            )}
                        </nav>
                    </div>
                    <div className=' mb-10'>
                        <button className="bg-red-500 text-white px-4 py-2 rounded-md w-full">Logout</button>
                    </div>
                </aside>
                {/* Main content */}
                <main className="flex-grow p-8 ml-64">
                    <h1 className="text-2xl font-semibold mb-6">Manage Posts</h1>
                    <div className="bg-white p-6 rounded shadow-md">
                        <div className="flex-grow">
                            {children}
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
