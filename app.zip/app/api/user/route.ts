import { NextResponse } from "next/server";
import path from "path";
import fs from "fs";
import prisma from "@/lib/db";

async function writeImageToPublic(fileName: string, imageBuffer: Buffer) {
  const filePath = path.join(process.cwd(), "public", "account", fileName);
  try {
    fs.writeFileSync(filePath, imageBuffer);
    console.log("Image written successfully");
  } catch (err) {
    console.error("Error writing image:", err);
    throw new Error("Unable to write image");
  }
}
export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const user_name = formData.get("user_name");
    const user_lastname = formData.get("user_lastname");
    // const emp_sex = formData.get("emp_sex");
    const user_date_of_birth = formData.get("user_date_of_birth");
    const user_email = formData.get("user_email");
    const user_tel = formData.get("user_tel");
    const user_username = formData.get("user_username");
    const user_password = formData.get("user_password");
    // const status_of_VIP = formData.get("status_of_VIP");
    

    const ID_card_photo = formData.get("ID_card_photo");
    const accom_rent_contrac_photo = formData.get(
      "accom_rent_contrac_photo"
    ) as File;

    console.log(
      "data------->",
      user_name,
      user_lastname,
      // emp_sex,
      user_date_of_birth,
      user_tel,
      user_username,
      user_password,
      // status_of_VIP,
      user_email,
      ID_card_photo,
      accom_rent_contrac_photo
    );

    if (!ID_card_photo || !(ID_card_photo instanceof File)) {
      return NextResponse.json({
        error: "Image file is required",
        status: 400,
      });
    }

    if (
      !user_name ||
      !user_lastname ||
      // !emp_sex ||
      !user_date_of_birth ||
      !user_tel ||
      !user_username ||
      !user_password ||
      // !status_of_VIP ||
      !user_email
    ) {
      return NextResponse.json({
        error: "All fields are required",
        status: 400,
      });
    }

    const arrayBuffer = await ID_card_photo.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const fileName = ID_card_photo.name;
    const filePath = `account/${fileName}`;
    await writeImageToPublic(fileName, buffer);
    
    let filePath2 = ``;
    if (accom_rent_contrac_photo) {
      const arrayBuffer2 = await accom_rent_contrac_photo?.arrayBuffer();
      const buffer2 = Buffer.from(arrayBuffer2);
      const fileName2 = accom_rent_contrac_photo?.name;
      filePath2 = `account/${fileName}`;
      await writeImageToPublic(fileName2, buffer2);
    }

    const data = await prisma.users.create({
      data: {
        user_name: user_name?.toString(),
        user_lastname: user_lastname?.toString(),
        // emp_sex: emp_sex?.toString(),
        user_date_of_birth: new Date(user_date_of_birth?.toString()),
        user_tel: user_tel?.toString(),
        user_username: user_username?.toString(),
        user_password: user_password?.toString(),
        // status_of_VIP: status_of_VIP?.toString(),
        user_email: user_email?.toString(),
        ID_card_photo: filePath?.toString(),
        accom_rent_contrac_photo: filePath2?.toString(),
      },
    });

    return NextResponse.json(data, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { error: "Something went wrong" + error },
      { status: 500 }
    );
  }
}
